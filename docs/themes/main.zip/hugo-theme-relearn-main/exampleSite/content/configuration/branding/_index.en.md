+++
alwaysopen = false
categories = ["reference"]
description = "Change colors and logos of your site"
title = "Branding"
weight = 2
+++

{{% children containerstyle="div" style="h2" description=true %}}
