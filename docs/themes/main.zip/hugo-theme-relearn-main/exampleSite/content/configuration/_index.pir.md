+++
categories = ["reference"]
menuPre = "<i class='fa-fw fas fa-gears'></i> "
title = "Configurrrat'n"
type = "chapter"
weight = 2
+++
{{< piratify >}}