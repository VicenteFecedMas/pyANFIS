+++
categories = ["explanation", "reference"]
description = "How to extend the topbar"
options = ["editURL"]
title = "Topbarrr"
weight = 4
+++
{{< piratify >}}