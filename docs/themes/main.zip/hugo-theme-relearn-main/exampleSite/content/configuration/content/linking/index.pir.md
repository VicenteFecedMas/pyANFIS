+++
categories = ["howto"]
description = "What options are available for links and images"
options = ["disableDefaultRelref", "disableExplicitIndexURLs"]
title = "Linking"
weight = 4
+++
{{< piratify >}}