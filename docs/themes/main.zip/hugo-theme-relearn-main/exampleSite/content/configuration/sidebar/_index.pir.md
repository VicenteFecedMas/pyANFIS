+++
alwaysopen = false
categories = ["reference"]
description = "Configure all things sidebar"
title = "Sidebar"
weight = 3
+++
{{< piratify >}}