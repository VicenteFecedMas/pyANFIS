+++
alwaysopen = false
categories = ["reference"]
description = "Configure all things sidebar"
title = "Sidebar"
weight = 3
+++

{{% children containerstyle="div" style="h2" description=true %}}
