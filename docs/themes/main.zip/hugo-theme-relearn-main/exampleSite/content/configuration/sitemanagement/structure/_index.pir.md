+++
categories = ["explanation"]
description = "Your site's directory structure"
title = "Directory Structure"
weight = 1
+++
{{< piratify >}}