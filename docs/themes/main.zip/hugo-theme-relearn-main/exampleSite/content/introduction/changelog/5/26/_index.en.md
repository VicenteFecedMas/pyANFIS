+++
disableToc = false
hidden = true
title = "Version 5.26"
type = "changelog"
weight = -26
+++

{{% pages showhidden="true" showdivider="true" reverse="true" %}}
