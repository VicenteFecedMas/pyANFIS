+++
disableToc = false
hidden = true
title = "Version 4.2"
type = "changelog"
weight = -2
+++
{{< piratify >}}
