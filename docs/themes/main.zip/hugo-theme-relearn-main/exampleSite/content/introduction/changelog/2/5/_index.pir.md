+++
disableToc = false
hidden = true
title = "Version 2.5"
type = "changelog"
weight = -5
+++
{{< piratify >}}
