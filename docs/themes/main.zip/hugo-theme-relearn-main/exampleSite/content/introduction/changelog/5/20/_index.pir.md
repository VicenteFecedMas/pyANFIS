+++
disableToc = false
hidden = true
title = "Version 5.20"
type = "changelog"
weight = -20
+++
{{< piratify >}}
