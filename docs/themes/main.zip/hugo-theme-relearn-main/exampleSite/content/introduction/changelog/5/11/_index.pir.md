+++
disableToc = false
hidden = true
title = "Version 5.11"
type = "changelog"
weight = -11
+++
{{< piratify >}}
