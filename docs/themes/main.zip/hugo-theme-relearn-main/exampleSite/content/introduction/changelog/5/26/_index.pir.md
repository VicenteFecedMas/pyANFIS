+++
disableToc = false
hidden = true
title = "Version 5.26"
type = "changelog"
weight = -26
+++
{{< piratify >}}
