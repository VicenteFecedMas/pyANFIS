+++
disableToc = false
hidden = true
title = "Version 2.7"
type = "changelog"
weight = -7
+++

{{% pages showhidden="true" showdivider="true" reverse="true" %}}
