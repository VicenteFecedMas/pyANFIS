+++
disableToc = false
hidden = true
title = "Version 1.1"
type = "changelog"
weight = -1
+++
{{< piratify >}}
