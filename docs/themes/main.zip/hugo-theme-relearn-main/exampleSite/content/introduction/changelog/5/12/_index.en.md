+++
disableToc = false
hidden = true
title = "Version 5.12"
type = "changelog"
weight = -12
+++

{{% pages showhidden="true" showdivider="true" reverse="true" %}}
