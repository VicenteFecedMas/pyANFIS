+++
disableToc = false
hidden = true
title = "Version 5.25"
type = "changelog"
weight = -25
+++
{{< piratify >}}
