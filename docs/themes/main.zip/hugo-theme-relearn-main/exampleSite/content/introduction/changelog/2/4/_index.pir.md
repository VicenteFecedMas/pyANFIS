+++
disableToc = false
hidden = true
title = "Version 2.4"
type = "changelog"
weight = -4
+++
{{< piratify >}}
