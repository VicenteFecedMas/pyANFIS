+++
disableToc = false
hidden = true
title = "Version 3.0"
type = "changelog"
weight = -0
+++
{{< piratify >}}
