+++
disableToc = false
hidden = true
title = "Version 5.12"
type = "changelog"
weight = -12
+++
{{< piratify >}}
