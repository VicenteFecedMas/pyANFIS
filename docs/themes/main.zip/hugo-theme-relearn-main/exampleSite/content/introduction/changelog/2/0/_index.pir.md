+++
disableToc = false
hidden = true
title = "Version 2.0"
type = "changelog"
weight = -0
+++
{{< piratify >}}
