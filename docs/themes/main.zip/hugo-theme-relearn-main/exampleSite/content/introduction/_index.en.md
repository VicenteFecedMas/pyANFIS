+++
menuPre = "<i class='fa-fw fas fa-star'></i> "
title = "Introduction"
type = "chapter"
weight = 1
+++

Discover what this Hugo theme is all about.

{{% children containerstyle="div" style="h2" description=true %}}
