+++
categories = ["howto"]
description = "Configure the topbar"
frontmatter = ["disableBreadcrumb", "disableNextPrev", "disableToc", "editURL"]
options = ["disableBreadcrumb", "disableNextPrev", "disableToc", "editURL"]
title = "Topbarrr"
weight = 4
+++
{{< piratify >}}