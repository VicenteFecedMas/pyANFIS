+++
description = "Setting the behavior of the menus"
title = "Menus"
weight = 2
menuPageRef = '/configuration/sidebar/menus'
+++
