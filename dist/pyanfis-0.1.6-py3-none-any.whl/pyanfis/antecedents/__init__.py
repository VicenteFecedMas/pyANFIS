from .antecedents import Antecedents

__all__ = ["Antecedents"]